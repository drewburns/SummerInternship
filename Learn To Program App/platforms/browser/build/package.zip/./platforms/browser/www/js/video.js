var xmlhttp;
            
    window.onload = function()
    {
//      alert("HI");
    }